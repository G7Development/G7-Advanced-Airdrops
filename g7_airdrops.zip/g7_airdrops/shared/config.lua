G7Drops = {}

G7Drops.Debug = false
G7Drops.Framework = 'auto' -- auto, qbx, qb, esx, standalone
G7Drops.Inventory = 'auto' -- auto, ox, qb, esx
G7Drops.AdminAce = 'g7airdrops.admin'
G7Drops.AdminGroups = { 'admin', 'god', 'superadmin' }

G7Drops.Commands = {
    create = 'airdropcreate',
    cancel = 'airdropcancel',
    status = 'airdropstatus',
    toggleAlerts = 'airdropalerts'
}

G7Drops.Drop = {
    maxActive = 3,
    playerCooldown = 300,
    claimDuration = 12,           -- seconds required to secure the crate
    crateLifetime = 900,          -- seconds after landing
    interactionDistance = 2.5,
    serverDistanceTolerance = 8.0,
    requireFlare = false,
    flareItem = 'g7_supply_flare',
    announceToAll = true,
    blip = { sprite = 478, color = 27, scale = 0.9 },
    smoke = { r = 151, g = 80, b = 190 }
}

G7Drops.Aircraft = {
    enabled = true,
    model = 'titan',
    altitude = 180.0,
    approachDistance = 650.0,
    speed = 45.0
}

G7Drops.Crate = {
    model = 'prop_box_wood02a_pu',
    parachute = 'p_cargo_chute_s',
    fallSpeed = 2.2
}

G7Drops.Locations = {
    vector3(5206.23, -5177.26, 11.93),
    vector3(5320.24, -5248.39, 32.58),
    vector3(5311.84, -5601.25, 64.67),
    vector3(4890.72, -5735.85, 26.35),
    vector3(4963.44, -5289.16, 6.24),
    vector3(4916.49, -4908.15, 3.37)
}

G7Drops.AutoEvent = {
    enabled = false,
    intervalMinutes = 120,
    minimumPlayers = 4,
    warningSeconds = 60
}

-- Each reward is rolled independently. Use item names supported by your inventory.
G7Drops.Rewards = {
    { item = 'bandage', label = 'Medical Supplies', min = 2, max = 5, chance = 75 },
    { item = 'armor', label = 'Armor', min = 1, max = 2, chance = 35 },
    { item = 'lockpick', label = 'Advanced Lockpick', min = 1, max = 2, chance = 25 },
    { item = 'markedbills', label = 'Marked Bills', min = 1, max = 3, chance = 20 }
}

G7Drops.Alert = {
    duration = 8500,
    sound = true,
    showCoordinates = false
}
