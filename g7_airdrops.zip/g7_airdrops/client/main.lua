
local activeDrops, alertMuted = {}, false

local function debug(message)
    if G7Drops.Debug then
        print(('[G7 Air Drops] %s'):format(message))
    end
end

local function notify(message, kind)
    lib.notify({
        title = 'G7 Advanced Air Drops',
        description = message,
        type = kind or 'inform',
        position = 'top-right'
    })
end

local function loadModel(model)
    local hash = type(model) == 'number' and model or joaat(model)

    if not IsModelInCdimage(hash) then
        return false
    end

    RequestModel(hash)

    local untilTime = GetGameTimer() + 10000

    while not HasModelLoaded(hash) and GetGameTimer() < untilTime do
        Wait(25)
    end

    return HasModelLoaded(hash), hash
end

local function loadGround(x, y, fallback)
    local ok, z = GetGroundZFor_3dCoord(x, y, fallback + 100.0, false)
    return ok and z or fallback
end

local function showAlert(payload)
    if alertMuted then return end

    SendNUIMessage({
        action = 'alert',
        payload = payload,
        duration = G7Drops.Alert.duration
    })
end

-- Clean up all entities, blips, and particle effects belonging to a drop.
local function removeDrop(id)
    local drop = activeDrops[id]
    if not drop then return end

    -- Stop this drop's smoke effect.
    if drop.smokeFx then
        StopParticleFxLooped(drop.smokeFx, false)
        drop.smokeFx = nil
    end

    -- Remove the crate.
    if drop.entity and DoesEntityExist(drop.entity) then
        DeleteEntity(drop.entity)
    end

    -- Remove any tracked parachute.
    if drop.parachute and DoesEntityExist(drop.parachute) then
        DeleteEntity(drop.parachute)
    end

    -- Remove the map blip.
    if drop.blip and DoesBlipExist(drop.blip) then
        RemoveBlip(drop.blip)
    end

    activeDrops[id] = nil
end

local function makeBlip(drop)
    if drop.blip and DoesBlipExist(drop.blip) then
        RemoveBlip(drop.blip)
    end

    drop.blip = AddBlipForCoord(
        drop.coords.x,
        drop.coords.y,
        drop.coords.z
    )

    SetBlipSprite(drop.blip, G7Drops.Drop.blip.sprite)
    SetBlipColour(drop.blip, G7Drops.Drop.blip.color)
    SetBlipScale(drop.blip, G7Drops.Drop.blip.scale)
    SetBlipAsShortRange(drop.blip, false)

    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString('G7 Supply Drop')
    EndTextCommandSetBlipName(drop.blip)
end

RegisterNetEvent('g7_airdrops:client:incoming', function(payload)
    activeDrops[payload.id] = {
        id = payload.id,
        coords = payload.coords,
        phase = 'incoming'
    }

    showAlert({
        title = payload.title,
        subtitle = payload.subtitle,
        detail = 'TRACKING SIGNAL ACQUIRED',
        tone = 'incoming'
    })

    if G7Drops.Aircraft.enabled then
        local c = payload.coords
        local angle = math.random() * math.pi * 2

        local sx = c.x + math.cos(angle) * G7Drops.Aircraft.approachDistance
        local sy = c.y + math.sin(angle) * G7Drops.Aircraft.approachDistance

        local ok, planeHash = loadModel(G7Drops.Aircraft.model)

        if ok then
            local ground = loadGround(sx, sy, c.z)

            local plane = CreateVehicle(
                planeHash,
                sx,
                sy,
                ground + G7Drops.Aircraft.altitude,
                GetHeadingFromVector_2d(c.x - sx, c.y - sy),
                false,
                false
            )

            SetEntityAsMissionEntity(plane, true, true)
            SetVehicleEngineOn(plane, true, true, false)
            SetEntityInvincible(plane, true)

            local endX = c.x - math.cos(angle) * G7Drops.Aircraft.approachDistance
            local endY = c.y - math.sin(angle) * G7Drops.Aircraft.approachDistance

            TaskPlaneMission(
                plane,
                0,
                0,
                0,
                endX,
                endY,
                ground + G7Drops.Aircraft.altitude,
                4,
                G7Drops.Aircraft.speed,
                0.0,
                GetEntityHeading(plane),
                100.0,
                50.0
            )

            activeDrops[payload.id].plane = plane

            SetModelAsNoLongerNeeded(planeHash)
        end
    end

    -- The server owns the event phase.
    -- Clients only report the expected delivery point.
    CreateThread(function()
        Wait(25000)

        local drop = activeDrops[payload.id]

        if drop and drop.phase == 'incoming' then
            TriggerServerEvent(
                'g7_airdrops:server:landed',
                payload.id,
                payload.coords
            )
        end
    end)
end)

RegisterNetEvent('g7_airdrops:client:landed', function(id, coords, expires)
    local drop = activeDrops[id] or { id = id }

    -- Ignore duplicate landing events for an already landed drop.
    if drop.phase == 'landed' then
        return
    end

    drop.coords = coords
    drop.phase = 'landed'
    drop.expires = expires

    activeDrops[id] = drop

    makeBlip(drop)

    showAlert({
        title = 'SUPPLY PACKAGE LANDED',
        subtitle = 'Secure the crate before the signal expires.',
        detail = 'LOCATION LOCKED · G7 NETWORK',
        tone = 'landed'
    })

    CreateThread(function()
        local ok, chuteHash = loadModel(G7Drops.Crate.parachute)
        local crateOk, crateHash = loadModel(G7Drops.Crate.model)

        if not crateOk then
            return
        end

        -- The drop may have been removed while models were loading.
        if not activeDrops[id] then
            SetModelAsNoLongerNeeded(crateHash)

            if ok then
                SetModelAsNoLongerNeeded(chuteHash)
            end

            return
        end

        local c = coords
        local ground = loadGround(c.x, c.y, c.z)

        local chute

        if ok then
            chute = CreateObject(
                chuteHash,
                c.x,
                c.y,
                ground + 85.0,
                false,
                false,
                false
            )

            SetModelAsNoLongerNeeded(chuteHash)
        end

        local crate = CreateObject(
            crateHash,
            c.x,
            c.y,
            ground + 82.0,
            false,
            false,
            false
        )

        SetEntityAsMissionEntity(crate, true, true)

        if chute then
            AttachEntityToEntity(
                crate,
                chute,
                0,
                0.0,
                0.0,
                -1.5,
                0.0,
                0.0,
                0.0,
                false,
                false,
                false,
                false,
                2,
                true
            )
        end

        local z = ground + 82.0

        while z > ground + 0.5 and activeDrops[id] do
            z = math.max(
                ground + 0.5,
                z - G7Drops.Crate.fallSpeed * 0.05
            )

            SetEntityCoordsNoOffset(
                crate,
                c.x,
                c.y,
                z,
                false,
                false,
                false
            )

            if chute then
                SetEntityCoordsNoOffset(
                    chute,
                    c.x,
                    c.y,
                    z + 1.5,
                    false,
                    false,
                    false
                )
            end

            Wait(50)
        end

        -- Clean up objects if the drop was removed during descent.
        if not activeDrops[id] then
            if DoesEntityExist(crate) then
                DeleteEntity(crate)
            end

            if chute and DoesEntityExist(chute) then
                DeleteEntity(chute)
            end

            SetModelAsNoLongerNeeded(crateHash)
            return
        end

        DetachEntity(crate, true, true)
        PlaceObjectOnGroundProperly(crate)
        FreezeEntityPosition(crate, true)

        if chute and DoesEntityExist(chute) then
            DeleteEntity(chute)
        end

        drop.entity = crate
        drop.phase = 'landed'

        -- Start smoke and store its handle for reliable cleanup.
        if G7Drops.Drop.smoke and activeDrops[id] then
            UseParticleFxAssetNextCall('core')

            drop.smokeFx = StartParticleFxLoopedAtCoord(
                'exp_grd_flare',
                c.x,
                c.y,
                ground + 0.4,
                0.0,
                0.0,
                0.0,
                1.0,
                false,
                false,
                false,
                false
            )
        end

        SetModelAsNoLongerNeeded(crateHash)
    end)
end)

RegisterNetEvent('g7_airdrops:client:phase', function(id, phase, claimant)
    local drop = activeDrops[id]
    if not drop then return end

    drop.phase = phase
    drop.claimant = claimant

    -- The server confirms the claim before cleanup.
    if phase == 'claimed' then
        removeDrop(id)
    end
end)

RegisterNetEvent('g7_airdrops:client:remove', function(id)
    removeDrop(id)
end)

RegisterNetEvent('g7_airdrops:client:adminCreate', function(coords)
    TriggerServerEvent('g7_airdrops:server:requestDrop', coords)
end)

RegisterNetEvent('g7_airdrops:client:claimStarted', function(id, seconds)
    notify(
        ('Securing package. Hold position for %d seconds.'):format(seconds),
        'inform'
    )

    if lib and lib.progressCircle then
        local completed = lib.progressCircle({
            duration = seconds * 1000,
            label = 'SECURING SUPPLY PACKAGE',
            position = 'bottom',
            canCancel = true,
            disable = {
                move = true,
                car = true,
                combat = true
            }
        })

        if not completed then
            TriggerServerEvent('g7_airdrops:server:cancelClaim', id)
        end
    else
        Wait(seconds * 1000)
    end
end)

RegisterNetEvent('g7_airdrops:client:claimCancelled', function()
    notify(
        'Claim interrupted. The package is still available.',
        'warning'
    )
end)

RegisterNetEvent('g7_airdrops:client:claimComplete', function(id, rewards)
    if #rewards == 0 then
        notify(
            'The package was secured, but no rewards could be added. Check inventory capacity and item names.',
            'warning'
        )

        return
    end

    local lines = {}

    for _, reward in ipairs(rewards) do
        lines[#lines + 1] = ('%sx %s'):format(
            reward.amount,
            reward.label
        )
    end

    notify(
        'Package secured: ' .. table.concat(lines, ', '),
        'success'
    )
end)

CreateThread(function()
    while true do
        local wait = 900
        local ped = PlayerPedId()
        local pcoords = GetEntityCoords(ped)

        for id, drop in pairs(activeDrops) do
            if drop.phase == 'landed'
                and drop.entity
                and DoesEntityExist(drop.entity)
            then
                local dist = #(pcoords - GetEntityCoords(drop.entity))

                if dist < 15.0 then
                    wait = 0

                    if dist < G7Drops.Drop.interactionDistance then
                        lib.showTextUI(
                            '[E]  SECURE SUPPLY PACKAGE',
                            {
                                position = 'right-center',
                                icon = 'box-open'
                            }
                        )

                        if IsControlJustReleased(0, 38) then
                            TriggerServerEvent(
                                'g7_airdrops:server:beginClaim',
                                id
                            )

                            Wait(500)
                        end
                    end
                end
            end
        end

        if wait > 0 then
            lib.hideTextUI()
        end

        Wait(wait)
    end
end)

RegisterCommand(G7Drops.Commands.toggleAlerts, function()
    alertMuted = not alertMuted

    notify(
        alertMuted and 'G7 drop alerts muted.' or 'G7 drop alerts enabled.',
        'inform'
    )
end, false)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then
        return
    end

    for id in pairs(activeDrops) do
        removeDrop(id)
    end

    lib.hideTextUI()
end)
