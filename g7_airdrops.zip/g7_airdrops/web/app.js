const stack=document.getElementById('stack');
const clean=(value)=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function makeAlert(payload={},duration=8500){
 const tone=['incoming','landed','danger'].includes(payload.tone)?payload.tone:'incoming';
 const node=document.createElement('article');node.className=`alert ${tone}`;node.style.setProperty('--duration',`${duration}ms`);
 node.innerHTML=`<div class="head"><img class="logo" src="g7-logo.png" alt="G7"><div class="identity"><div class="eyebrow">G7 DEVELOPMENT / FIELD OPERATIONS</div><div class="title">${clean(payload.title||'SUPPLY DROP DETECTED')}</div><div class="subtitle">${clean(payload.subtitle||'A supply package is available.')}</div></div><div class="status">${tone==='landed'?'ON GROUND':tone==='danger'?'THREAT':'LIVE'}</div></div><div class="footer"><span class="signal"><i class="dot"></i>${clean(payload.detail||'SECURE THE AREA')}</span><span>G7 // AIR DIVISION</span></div><div class="bar"><span></span></div>`;
 stack.prepend(node);
 while(stack.children.length>3)stack.lastElementChild.remove();
 const remove=()=>{if(!node.isConnected)return;node.classList.add('exit');setTimeout(()=>node.remove(),300)};
 node.addEventListener('animationend',e=>{if(e.animationName==='enter'){}});
 setTimeout(remove,Math.max(2000,duration));
}
window.addEventListener('message',event=>{const data=event.data||{};if(data.action==='alert')makeAlert(data.payload||{},Number(data.duration)||8500)});
