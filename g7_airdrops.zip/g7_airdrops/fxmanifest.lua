fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'G7 Development'
description 'G7 Advanced Air Drops - dynamic supply events, secure loot claiming, and premium alerts'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'shared/config.lua'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    'server/bridge.lua',
    'server/main.lua'
}

ui_page 'web/index.html'

files {
    'web/index.html',
    'web/style.css',
    'web/app.js',
    'web/g7-logo.png'
}


escrow_ignore {
    'shared/config.lua',
    'README.md',
    'LICENSE.md',
}

dependencies {
    'ox_lib'
}
