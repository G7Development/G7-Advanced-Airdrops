G7Bridge = {}

local function resourceStarted(name)
    return GetResourceState(name) == 'started'
end

function G7Bridge.Framework()
    local configured = G7Drops.Framework
    if configured ~= 'auto' then return configured end
    if resourceStarted('qbx_core') or resourceStarted('qbx-core') then return 'qbx' end
    if resourceStarted('qb-core') then return 'qb' end
    if resourceStarted('es_extended') then return 'esx' end
    return 'standalone'
end

function G7Bridge.Inventory()
    local configured = G7Drops.Inventory
    if configured ~= 'auto' then return configured end
    if resourceStarted('ox_inventory') then return 'ox' end
    if resourceStarted('qb-inventory') then return 'qb' end
    return 'framework'
end

function G7Bridge.IsAdmin(src)
    if src == 0 then return true end
    if IsPlayerAceAllowed(src, G7Drops.AdminAce) then return true end
    local fw = G7Bridge.Framework()
    if fw == 'qb' or fw == 'qbx' then
        local ok, player = pcall(function() return exports['qb-core']:GetCoreObject().Functions.GetPlayer(src) end)
        if ok and player and player.PlayerData and player.PlayerData.permission then
            for _, group in ipairs(G7Drops.AdminGroups) do
                if player.PlayerData.permission == group then return true end
            end
        end
    elseif fw == 'esx' then
        local ok, xPlayer = pcall(function() return exports.es_extended:getSharedObject().GetPlayerFromId(src) end)
        if ok and xPlayer and xPlayer.getGroup then
            local group = xPlayer.getGroup()
            for _, allowed in ipairs(G7Drops.AdminGroups) do if group == allowed then return true end end
        end
    end
    return false
end

function G7Bridge.HasItem(src, item, count)
    count = count or 1
    local inv = G7Bridge.Inventory()
    if inv == 'ox' then
        local ok, amount = pcall(function() return exports.ox_inventory:GetItemCount(src, item) end)
        return ok and (tonumber(amount) or 0) >= count
    end
    local fw = G7Bridge.Framework()
    if fw == 'qb' or fw == 'qbx' then
        local ok, player = pcall(function() return exports['qb-core']:GetCoreObject().Functions.GetPlayer(src) end)
        if ok and player then
            local found = player.Functions.GetItemByName(item)
            return found and (found.amount or 0) >= count or false
        end
    elseif fw == 'esx' then
        local ok, xPlayer = pcall(function() return exports.es_extended:getSharedObject().GetPlayerFromId(src) end)
        if ok and xPlayer then local found = xPlayer.getInventoryItem(item); return found and (found.count or 0) >= count end
    end
    return false
end

function G7Bridge.RemoveItem(src, item, count)
    local inv = G7Bridge.Inventory()
    if inv == 'ox' then
        local ok, result = pcall(function() return exports.ox_inventory:RemoveItem(src, item, count) end)
        return ok and result == true
    end
    local fw = G7Bridge.Framework()
    if fw == 'qb' or fw == 'qbx' then
        local ok, player = pcall(function() return exports['qb-core']:GetCoreObject().Functions.GetPlayer(src) end)
        return ok and player and player.Functions.RemoveItem(item, count) == true or false
    elseif fw == 'esx' then
        local ok, xPlayer = pcall(function() return exports.es_extended:getSharedObject().GetPlayerFromId(src) end)
        if ok and xPlayer then xPlayer.removeInventoryItem(item, count); return true end
    end
    return false
end

function G7Bridge.GiveItem(src, item, count)
    local inv = G7Bridge.Inventory()
    if inv == 'ox' then
        local ok, result = pcall(function() return exports.ox_inventory:AddItem(src, item, count) end)
        return ok and result == true
    end
    local fw = G7Bridge.Framework()
    if fw == 'qb' or fw == 'qbx' then
        local ok, player = pcall(function() return exports['qb-core']:GetCoreObject().Functions.GetPlayer(src) end)
        return ok and player and player.Functions.AddItem(item, count) == true or false
    elseif fw == 'esx' then
        local ok, xPlayer = pcall(function() return exports.es_extended:getSharedObject().GetPlayerFromId(src) end)
        if ok and xPlayer then xPlayer.addInventoryItem(item, count); return true end
    end
    return false
end
