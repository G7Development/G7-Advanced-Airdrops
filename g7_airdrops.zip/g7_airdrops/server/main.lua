local drops, cooldowns = {}, {}
local nextId = 0

local function log(message)
    if G7Drops.Debug then print(('[G7 Advanced Air Drops] %s'):format(message)) end
end

local function notify(src, title, description, kind)
    TriggerClientEvent('ox_lib:notify', src, { title = title, description = description, type = kind or 'inform' })
end

local function broadcast(event, ...)
    TriggerClientEvent(event, -1, ...)
end

local function countPlayers()
    return #GetPlayers()
end

local function coordsTable(coords)
    return { x = coords.x + 0.0, y = coords.y + 0.0, z = coords.z + 0.0 }
end

local function distance(a, b)
    local dx, dy, dz = a.x - b.x, a.y - b.y, a.z - b.z
    return math.sqrt(dx*dx + dy*dy + dz*dz)
end

local function chooseLocation()
    if #G7Drops.Locations == 0 then return nil end
    return G7Drops.Locations[math.random(1, #G7Drops.Locations)]
end

local function rollRewards()
    local result = {}
    for _, reward in ipairs(G7Drops.Rewards) do
        if math.random(100) <= math.max(0, math.min(100, reward.chance or 0)) then
            result[#result+1] = {
                item = reward.item,
                label = reward.label or reward.item,
                amount = math.random(reward.min or 1, reward.max or 1)
            }
        end
    end
    if #result == 0 and #G7Drops.Rewards > 0 then
        local reward = G7Drops.Rewards[math.random(#G7Drops.Rewards)]
        result[1] = { item = reward.item, label = reward.label or reward.item, amount = math.random(reward.min or 1, reward.max or 1) }
    end
    return result
end

local function createDrop(coords, source, isAutomatic)
    local active = 0
    for _ in pairs(drops) do active = active + 1 end
    if active >= G7Drops.Drop.maxActive then
        if source and source > 0 then notify(source, 'G7 Air Drops', 'Maximum active supply drops reached.', 'error') end
        return false
    end
    nextId = nextId + 1
    local id = ('g7-%d-%d'):format(os.time(), nextId)
    drops[id] = {
        id = id, coords = coordsTable(coords), phase = 'incoming',
        created = os.time(), expires = nil, owner = source or 0,
        automatic = isAutomatic == true, claimant = nil, claimToken = nil
    }
    broadcast('g7_airdrops:client:incoming', {
        id = id, coords = drops[id].coords, expiresIn = G7Drops.Drop.crateLifetime,
        title = isAutomatic and 'UNIDENTIFIED SUPPLY DROP' or 'SUPPLY DROP CONFIRMED',
        subtitle = isAutomatic and 'Unscheduled cargo detected. Secure the site.' or 'A G7 supply package is inbound.'
    })
    log(('Created %s at %.2f %.2f %.2f'):format(id, coords.x, coords.y, coords.z))
    return id
end

RegisterNetEvent('g7_airdrops:server:requestDrop', function(coords)
    local src = source
    if type(coords) ~= 'table' or type(coords.x) ~= 'number' or type(coords.y) ~= 'number' or type(coords.z) ~= 'number' then return end
    if not G7Bridge.IsAdmin(src) then
        notify(src, 'G7 Air Drops', 'You are not authorized to create a supply drop.', 'error')
        return
    end
    local now = os.time()
    if cooldowns[src] and now - cooldowns[src] < G7Drops.Drop.playerCooldown then
        notify(src, 'G7 Air Drops', 'A supply event was recently created. Wait before starting another.', 'warning')
        return
    end
    if G7Drops.Drop.requireFlare and not G7Bridge.HasItem(src, G7Drops.Drop.flareItem, 1) then
        notify(src, 'G7 Air Drops', ('Required item missing: %s'):format(G7Drops.Drop.flareItem), 'error')
        return
    end
    if G7Drops.Drop.requireFlare and not G7Bridge.RemoveItem(src, G7Drops.Drop.flareItem, 1) then
        notify(src, 'G7 Air Drops', 'Could not consume the flare. Try again.', 'error')
        return
    end
    local id = createDrop(vector3(coords.x, coords.y, coords.z), src, false)
    if id then cooldowns[src] = now end
end)

RegisterNetEvent('g7_airdrops:server:landed', function(id, coords)
    local src = source
    local drop = drops[id]
    if not drop or drop.phase ~= 'incoming' or type(coords) ~= 'table' then return end
    if type(coords.x) ~= 'number' or type(coords.y) ~= 'number' or type(coords.z) ~= 'number' then return end
    if distance(coords, drop.coords) > 90.0 then
        log(('Rejected invalid landing report from %s for %s'):format(src, id))
        return
    end
    drop.coords = coordsTable(vector3(coords.x, coords.y, coords.z))
    drop.phase = 'landed'
    drop.expires = os.time() + G7Drops.Drop.crateLifetime
    broadcast('g7_airdrops:client:landed', id, drop.coords, drop.expires)
end)

RegisterNetEvent('g7_airdrops:server:beginClaim', function(id)
    local src = source
    local drop = drops[id]
    if not drop or drop.phase ~= 'landed' or drop.claimant then return end
    local ped = GetPlayerPed(src)
    if ped == 0 then return end
    local p = GetEntityCoords(ped)
    if #(p - vector3(drop.coords.x, drop.coords.y, drop.coords.z)) > G7Drops.Drop.interactionDistance + G7Drops.Drop.serverDistanceTolerance then
        notify(src, 'G7 Air Drops', 'Move closer to the supply crate.', 'error')
        return
    end
    drop.phase, drop.claimant = 'securing', src
    drop.claimToken = ('%s:%s:%s'):format(id, src, math.random(100000, 999999))
    TriggerClientEvent('g7_airdrops:client:claimStarted', src, id, G7Drops.Drop.claimDuration)
    broadcast('g7_airdrops:client:phase', id, 'securing', src)
    local token = drop.claimToken
    SetTimeout(G7Drops.Drop.claimDuration * 1000, function()
        local current = drops[id]
        if not current or current.phase ~= 'securing' or current.claimToken ~= token or current.claimant ~= src then return end
        local playerPed = GetPlayerPed(src)
        if playerPed == 0 then current.phase, current.claimant, current.claimToken = 'landed', nil, nil; return end
        local playerCoords = GetEntityCoords(playerPed)
        if #(playerCoords - vector3(current.coords.x, current.coords.y, current.coords.z)) > G7Drops.Drop.interactionDistance + G7Drops.Drop.serverDistanceTolerance then
            current.phase, current.claimant, current.claimToken = 'landed', nil, nil
            TriggerClientEvent('g7_airdrops:client:claimCancelled', src, id)
            broadcast('g7_airdrops:client:phase', id, 'landed', nil)
            return
        end
        local rewards = rollRewards()
        local granted = {}
        for _, reward in ipairs(rewards) do
            if G7Bridge.GiveItem(src, reward.item, reward.amount) then
                granted[#granted+1] = { label = reward.label, amount = reward.amount }
            end
        end
        current.phase, current.claimant, current.claimToken = 'claimed', nil, nil
        TriggerClientEvent('g7_airdrops:client:claimComplete', src, id, granted)
        broadcast('g7_airdrops:client:phase', id, 'claimed', src)
    end)
end)

RegisterNetEvent('g7_airdrops:server:cancelClaim', function(id)
    local src = source
    local drop = drops[id]
    if drop and drop.phase == 'securing' and drop.claimant == src then
        drop.phase, drop.claimant, drop.claimToken = 'landed', nil, nil
        broadcast('g7_airdrops:client:phase', id, 'landed', nil)
    end
end)

RegisterCommand(G7Drops.Commands.create, function(src)
    if src == 0 then print('Use the in-game command to create a drop at your position.'); return end
    local ped = GetPlayerPed(src)
    local c = GetEntityCoords(ped)
    TriggerClientEvent('g7_airdrops:client:adminCreate', src, coordsTable(c))
end, false)

RegisterCommand(G7Drops.Commands.cancel, function(src, args)
    if not G7Bridge.IsAdmin(src) then if src > 0 then notify(src, 'G7 Air Drops', 'Not authorized.', 'error') end return end
    local id = args[1]
    if id and drops[id] then drops[id] = nil; broadcast('g7_airdrops:client:remove', id); return end
    local removed = 0
    for dropId in pairs(drops) do drops[dropId] = nil; broadcast('g7_airdrops:client:remove', dropId); removed = removed + 1 end
    if src > 0 then notify(src, 'G7 Air Drops', ('Removed %d active drop(s).'):format(removed), 'success') end
end, false)

RegisterCommand(G7Drops.Commands.status, function(src)
    local total, landed = 0, 0
    for _, drop in pairs(drops) do total = total + 1; if drop.phase == 'landed' then landed = landed + 1 end end
    local message = ('Active drops: %d | Landed and claimable: %d'):format(total, landed)
    if src == 0 then print(message) else notify(src, 'G7 Air Drops', message, 'inform') end
end, false)

CreateThread(function()
    while true do
        Wait(15000)
        local now = os.time()
        for id, drop in pairs(drops) do
            if drop.expires and now >= drop.expires then
                drops[id] = nil
                broadcast('g7_airdrops:client:remove', id)
            end
        end
    end
end)

CreateThread(function()
    while true do
        Wait(math.max(1, G7Drops.AutoEvent.intervalMinutes) * 60000)
        if G7Drops.AutoEvent.enabled and countPlayers() >= G7Drops.AutoEvent.minimumPlayers then
            local loc = G7Drops.Locations[math.random(1, #G7Drops.Locations)]
            createDrop(loc, 0, true)
        end
    end
end)

AddEventHandler('playerDropped', function()
    local src = source
    cooldowns[src] = nil
    for _, drop in pairs(drops) do
        if drop.claimant == src and drop.phase == 'securing' then
            drop.phase, drop.claimant, drop.claimToken = 'landed', nil, nil
            broadcast('g7_airdrops:client:phase', drop.id, 'landed', nil)
        end
    end
end)

exports('GetActiveDrops', function()
    local out = {}
    for id, drop in pairs(drops) do out[#out+1] = { id = id, phase = drop.phase, coords = drop.coords, expires = drop.expires } end
    return out
end)
